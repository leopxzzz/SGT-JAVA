package fuctura.model;

public class Login {
	
	private String login = "ADMIN";
	private String senha = "SENHA123";
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}

}
