package fuctura.model;

public class Time {
	
	private String nome2;
	private int qtdTitulos;
	
	public String getNome() {
		return nome2;
	}
	public void setNome(String nome2) {
		this.nome2 = nome2;
	}
	public int getQtdTitulos() {
		return qtdTitulos;
	}
	public void setQtdTitulos(int qtdTitulos) {
		this.qtdTitulos = qtdTitulos;
	}
	

}
