package fuctura.model;

public class Jogador {
 private String jogador;
 private int camisa;
 private int idade;
 private double altura;
 private int codigo;


public String getJogador() {
	return jogador;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public void setJogador(String jogador) {
	this.jogador = jogador;
}
public int getCamisa() {
	return camisa;
}
public void setCamisa(int camisa) {
	this.camisa = camisa;
}
public int getIdade() {
	return idade;
}
public void setIdade(int idade) {
	this.idade = idade;
}
public double getAltura() {
	return altura;
}
public void setAltura(double altura) {
	this.altura = altura;
}


 
 
}
