package fuctura.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import fuctura.model.Clube;
import fuctura.model.Jogador;

public class ClubeDAO {

	public void salvar(Connection conexao, Clube clube) {
		String sql = "insert into clube (nome, capacidade, dtFundacao)\r\n" + "values (?, ?, ?)";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, clube.getNome());
			ps.setInt(2, clube.getCapacidade());
			ps.setString(3, clube.getDtFundacao());

			ps.execute();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		System.out.println("Registro feito com sucesso!");
	}

	public ArrayList<Clube> recuperar(Connection conexao) {

		System.out.println("Consultando no banco de dados...\n");

		String sql2 = "select nome, capacidade, dtFundacao from clube";

		ArrayList<Clube> clubes = new ArrayList<Clube>();

		try {
			PreparedStatement ps = conexao.prepareStatement(sql2);
			ResultSet resultadoConsulta = ps.executeQuery();

			while (resultadoConsulta.next()) {

				String nome = resultadoConsulta.getString("nome");
				int capmx = resultadoConsulta.getInt("capacidade");
				String dtFundacao = resultadoConsulta.getString("dtFundacao");
						

				Clube c = new Clube();

			c.setNome(nome);
			c.setCapacidade(capmx);
			c.setDtFundacao(dtFundacao);
			

				clubes.add(c);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return clubes;

	}

}
