package fuctura.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import fuctura.model.Time;

public class TimeDAO {
	
	
	public void salvar(Connection conexao, Time time) {
		String sql = "insert into time (nome2, qtdTitulos)\r\n" + "values (?, ?)";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, time.getNome());
			ps.setInt(2, time.getQtdTitulos());
			
			

			ps.execute();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		System.out.println("Registro feito com sucesso!");
	}
	
	public ArrayList<Time> recuperar(Connection conexao) {

		System.out.println("Consultando no banco de dados...\n");

		String sql3 = "select nome2, qtdTitulos from time";

		ArrayList<Time> times = new ArrayList<Time>();

		try {
			PreparedStatement ps = conexao.prepareStatement(sql3);
			ResultSet resultadoConsulta = ps.executeQuery();

			while (resultadoConsulta.next()) {

				String nome2 = resultadoConsulta.getString("nome2");
				int titulos = resultadoConsulta.getInt("qtdTitulos");
			
						

				Time t = new Time();
				

			t.setNome(nome2);
			t.setQtdTitulos(titulos);
			
			

				times.add(t);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return times;

	}

}
