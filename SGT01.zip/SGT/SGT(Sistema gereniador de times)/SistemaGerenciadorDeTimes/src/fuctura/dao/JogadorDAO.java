package fuctura.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.naming.spi.DirStateFactory.Result;

import fuctura.model.Jogador;

public class JogadorDAO {

	Scanner scan = new Scanner(System.in);

	public void salvar(Connection conexao, Jogador jogador) {
		String sql = "insert into jogador (nome, camisa, idade, altura)\r\n" + "values (?, ?, ?, ?)";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, jogador.getJogador());
			ps.setInt(2, jogador.getCamisa());
			ps.setInt(3, jogador.getIdade());
			ps.setDouble(4, jogador.getAltura());

			ps.execute();
			System.out.println("Registro feito com sucesso!");
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public ArrayList<Jogador> recuperar(Connection conexao) {

		System.out.println("Consultando no banco de dados...\n");

		String sql1 = "select nome, camisa, idade, altura, codigo from jogador";

		ArrayList<Jogador> todosJogadores = new ArrayList<Jogador>();

		try {
			PreparedStatement ps = conexao.prepareStatement(sql1);
			ResultSet resultadoConsulta = ps.executeQuery();

			while (resultadoConsulta.next()) {

				String nome = resultadoConsulta.getString("nome");
				int camisa = resultadoConsulta.getInt("camisa");
				int idade = resultadoConsulta.getInt("idade");
				double altura = resultadoConsulta.getDouble("altura");
				int codigo = resultadoConsulta.getInt("codigo");

				Jogador j = new Jogador();

				j.setJogador(nome);
				j.setCamisa(camisa);
				j.setIdade(idade);
				j.setAltura(altura);
				j.setCodigo(codigo);

				todosJogadores.add(j);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return todosJogadores;

	}

	public void excluir(Connection conexao, Jogador jogadorQueQueroExcluir) {

		String SQL = "delete from jogador where codigo = ?";

		int chavePrimaria = jogadorQueQueroExcluir.getCodigo();

		try {
			PreparedStatement ps = conexao.prepareStatement(SQL);

			ps.setInt(1, chavePrimaria);

			ps.execute();

			System.out.println("Excluido com sucesso");

		} catch (SQLException e) {
			System.out.println("N�o foi poss�vel excluir o jogador");

			e.printStackTrace();
		}

	}

	public void atualizar(Connection conexao, Jogador jogadorAtualizar) {
		try {

			String comandoSQL = "UPDATE jogador SET nome = ?, camisa= ?, altura= ?, idade= ? WHERE codigo= ?;";

			PreparedStatement ps = conexao.prepareStatement(comandoSQL);

			ps.setString(1, jogadorAtualizar.getJogador());

			ps.setInt(2, jogadorAtualizar.getCamisa());

			ps.setInt(3, jogadorAtualizar.getIdade());

			ps.setDouble(4, jogadorAtualizar.getAltura());

			ps.setInt(5, jogadorAtualizar.getCodigo());

			ps.executeUpdate();
			ps.close();
			
		

			System.out.println("Atualizado com Sucesso!");

		} catch (SQLException e) {
			System.out.println("ERRO");
			e.printStackTrace();
		}

	}

	public void atualizarNome(Connection conexao, Jogador jogadorAtualizar) {

		String comandoSQL = "update jogador set nome = ? where codigo = ?";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(comandoSQL);

			ps.setString(1, jogadorAtualizar.getJogador());
			ps.setInt(2, jogadorAtualizar.getCodigo());

			ps.execute();
			ps.close();
			
			System.out.println("Atualizado com Sucesso!");
			

			
		} catch (SQLException e) {
			System.out.println("aqui errou");
			e.printStackTrace();
		}

	}

	public void atualizaCamisa(Connection conexao, Jogador jogadorAtualizar) {

		String comandoSQL = "update jogador set camisa = ? where codigo = ?";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(comandoSQL);

			ps.setInt(1, jogadorAtualizar.getCamisa());
			ps.setInt(2, jogadorAtualizar.getCodigo());

			ps.execute();
			ps.close();
			
			System.out.println("Atualizado com Sucesso!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void atualizarIdade(Connection conexao, Jogador jogadorAtualizar) {

		String comandoSQL = "UPDATE jogador SET idade = ? where codigo = ?";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(comandoSQL);

			ps.setInt(1, jogadorAtualizar.getIdade());
			ps.setInt(2, jogadorAtualizar.getCodigo());

			ps.execute();
			ps.close();
			
			System.out.println("Atualizado com Sucesso!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void atualizarAltura(Connection conexao, Jogador jogadorAtualizar) {

		String comandoSQL = "UPDATE jogador SET altura = ? where codigo = ?";

		PreparedStatement ps;
		try {
			ps = conexao.prepareStatement(comandoSQL);

			ps.setDouble(1, jogadorAtualizar.getAltura());
			ps.setInt(2, jogadorAtualizar.getCodigo());

			ps.execute();
			ps.close();
			
			System.out.println("Atualizado com Sucesso!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

}
