	package fuctura;
		
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.Scanner;
	
	import fuctura.dao.ClubeDAO;
	import fuctura.dao.JogadorDAO;
	import fuctura.dao.TimeDAO;
	import fuctura.model.Clube;
	import fuctura.model.Jogador;
	import fuctura.model.Login;
	import fuctura.model.Time;
	
	public class Principal {
	
		public static void main(String[] args) {
	
			Login login = new Login();
	
			String user = "";
			String pass = "";
	
			String USUARIO = "leonardo";
			String SENHA = "root@123";
	
			int opc = 0;
	
			Scanner scan = new Scanner(System.in);
	
			do {
	
				System.out.println("Digite o seu Usuario: ");
				user = scan.nextLine();
				System.out.println("Digite a senha: ");
				pass = scan.nextLine();
				
				if(!login.getLogin().equals(user) && !login.getSenha().equals(pass) || user.isEmpty() || pass.isEmpty()) {
					System.out.println("Credenciais invalidas\n");
				}
	
			} while (!login.getLogin().equals(user) && !login.getSenha().equals(pass));
	
			System.out.println("Logado Com Sucesso!\n");
	
			try {
	
				Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/jpa", USUARIO, SENHA);
	
				JogadorDAO jdao = new JogadorDAO();
	
				ClubeDAO clbdao = new ClubeDAO();
	
				TimeDAO tmdao = new TimeDAO();
				String jogador;
	
				do {
	
					System.out.println("Bem Vindo Ao Sistema Gerenciador de Times!\n\n");
					System.out.println("Digite:\n1 para inserir um jogador novo\n2 Para resgatar dados dos jogadores\n"
							+ "3 Para alterar dados de jogador\n4 Para excluir um jogador\n5 Para incluir um Clube\n6"
							+ " Para recuperar dados dos Clubes\n7 para inserir um time\n8 Para Listar todos os times\n"
							+ "0 Para encerrar aplicacaoo");
					opc = scan.nextInt();
	
					switch (opc) {
					case 1:
	
						System.out.println("Digite o nome do Jogador: ");
						jogador = scan.next();
						System.out.println("Digite o numero da camisa do Jogador: ");
						int camisa = scan.nextInt();
						System.out.println("Digite a idade do Jogador: ");
						int idade = scan.nextInt();
						System.out.println("Digite a altura do Jogador: ");
						double altura = scan.nextDouble();
	
						Jogador j1 = new Jogador();
						j1.setJogador(jogador);
						j1.setCamisa(camisa);
						j1.setIdade(idade);
						j1.setAltura(altura);
	
						jdao.salvar(conexao, j1);
						break;
	
					case 2:
						ArrayList<Jogador> jogadoresDaMinhaTabela = jdao.recuperar(conexao);
	
						for (Jogador jogador1 : jogadoresDaMinhaTabela) {
							System.out.println("Nome: " + jogador1.getJogador() + "\n" + "Idade: " + jogador1.getIdade()
									+ "\n" + "Camisa: " + jogador1.getCamisa() + "\n" + "Altura: " + jogador1.getAltura()
									+ "\n");
						}
	
						break;
	
					case 3:
	
						Jogador jog = new Jogador();
	
						int index;
	
						Jogador j = new Jogador();
						do {
	
							ArrayList<Jogador> todos = jdao.recuperar(conexao);
	
							for (Jogador jogadorech : todos) {
								System.out.println("------------------------------------------");
								System.out.println("Codigo: " + jogadorech.getCodigo() + "\n");
								System.out.println("Nome: " + jogadorech.getJogador() + "\n");
								System.out.println("Camisa: " + jogadorech.getCamisa() + "\n");
								System.out.println("Idade: " + jogadorech.getIdade());
								System.out.println("------------------------------------------\n");
							}
	
							System.out.println("Digite o codigo do jogador escolhido: ");
	
							int codjog = scan.nextInt();
	
							for (int i = 0; codjog >= i; i++) {
								System.out.println("Voce quer atualizar todas as informacoes do jogador: " + codjog + "?");
	
								break;
							}
	
							System.out.println(
									"Digite:\n1 - SIM\n2 - Nao, alterar apenas uma informacao\n0 - Escolher outro codigo de Jogador\n");
							index = scan.nextInt();
	
							switch (index) {
							case 1:
	
								System.out.println("Digite o novo nome do Jogador: ");
								String jogadorr = scan.next();
								System.out.println("Digite o novo numero da camisa do Jogador: ");
								int camisaa = scan.nextInt();
								System.out.println("Digite a nova idade do Jogador: ");
								int idadee = scan.nextInt();
								System.out.println("Digite a nova altura do Jogador: ");
								double alturaa = scan.nextDouble();
	
								j.setJogador(jogadorr);
								j.setCamisa(camisaa);
								j.setIdade(idadee);
								j.setAltura(alturaa);
								j.setCodigo(codjog);// recebe o id digitado pelo usuario
	
								jdao.atualizar(conexao, j);
	
								break;
	
							case 2:
								System.out.println("Qual Informacao voce deseja alterar?");
								System.out.println(" 1 - Nome");
								System.out.println(" 2 - Camisa");
								System.out.println(" 3 - Idade");
								System.out.println(" 4 - Altura");
	
								int opc1 = scan.nextInt();
	
								switch (opc1) {
								case 1:
									System.out.println("Digite o novo nome do Jogador: ");
									String jogador2 = scan.next();
	
									j.setJogador(jogador2);
									j.setCodigo(codjog);
	
									jdao.atualizarNome(conexao, j);
									break;
	
								case 2:
	
									System.out.println("Digite a nova camisa do Jogador: ");
									int jogador3 = scan.nextInt();
	
									j.setCamisa(jogador3);
									j.setCodigo(codjog);
	
									jdao.atualizaCamisa(conexao, j);
									break;
	
								case 3:
	
									System.out.println("Digite a nova idade do Jogador: ");
									int jogadori = scan.nextInt();
	
									j.setIdade(jogadori);
									j.setCodigo(codjog);
	
									jdao.atualizarIdade(conexao, j);
									break;
	
								case 4:
									System.out.println("Digite a nova altura do Jogador: ");
									double jogadoral = scan.nextDouble();
	
									j.setAltura(jogadoral);
									j.setCodigo(codjog);
	
									jdao.atualizarAltura(conexao, j);
									break;
	
								}
	
							}
	
						} while (index == 0);
	
						break;
	
					case 4:
	
						JogadorDAO jog1 = new JogadorDAO();
	
						ArrayList<Jogador> todos = jog1.recuperar(conexao);
	
						for (Jogador jogadoreech : todos) {
							System.out.println("------------------------------------------");
							System.out.println("Codigo: " + jogadoreech.getCodigo() + "\n");
							System.out.println("Nome: " + jogadoreech.getJogador() + "\n");
							System.out.println("Camisa: " + jogadoreech.getCamisa() + "\n");
							System.out.println("Idade: " + jogadoreech.getIdade());
							System.out.println("------------------------------------------\n");
						}
	
						System.out.println("Digite o codigo do jogador escolhido: ");
	
						int codjog = scan.nextInt();
	
						Jogador alguem = new Jogador();
	
						alguem.setCodigo(codjog);
	
						jog1.excluir(conexao, alguem);
	
						break;
	
					case 5:
						System.out.println("Digite o nome do Clube: ");
						String clube = scan.next();
						System.out.println("Digite a capacidade maxima do estadio: ");
						int capmx = scan.nextInt();
						System.out.println("Digite a data de fundacao(DD/MM/AAAA): ");
						String dtFundacao = scan.next();
	
						Clube clb = new Clube();
	
						clb.setNome(clube);
						clb.setCapacidade(capmx);
						clb.setDtFundacao(dtFundacao);
	
						clbdao.salvar(conexao, clb);
	
						break;
	
					case 6:
						ArrayList<Clube> clubes = clbdao.recuperar(conexao);
	
						for (Clube clubes1 : clubes) {
							System.out.println(
									"Nome: " + clubes1.getNome() + "\n" + "Capacidade Maxima: " + clubes1.getCapacidade()
											+ "\n" + "Data de Fundacao: " + clubes1.getDtFundacao() + "\n");
						}
	
						break;
	
					case 7:
						System.out.println("Digite o nome do Time: ");
						String time = scan.next();
						System.out.println("Digite a quantidade de titulos: ");
						int qtdt = scan.nextInt();
	
						Time tm = new Time();
	
						tm.setNome(time);
						tm.setQtdTitulos(qtdt);
	
						tmdao.salvar(conexao, tm);
						break;
	
					case 8:
						ArrayList<Time> times = tmdao.recuperar(conexao);
	
						for (Time times1 : times) {
							System.out.println("Nome: " + times1.getNome() + "\n" + "Quantidade de Titulos: "
									+ times1.getQtdTitulos() + "\n");
						}
						break;
	
					case 0:
	
						break;
	
					default:
						System.out.println("Op��o invalida");
	
						break;
	
					}
	
				} while (opc != 0);// continua apenas se for verdadeiro
			} catch (SQLException e) {
				System.out.println("Ocorreu um problema ao acassar o banco de dados");
				e.printStackTrace();
			}
	
			System.out.println("encerrado");
		}
	
	}
